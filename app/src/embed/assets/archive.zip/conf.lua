function love.conf(t)
    t.window.vsync = 1       -- هماهنگی با نرخ نوسازی گوشی برای فریم‌ریت کاملاً روان
    t.window.msaa = 4        -- فعال کردن مستقیم Anti-Aliasing سخت‌افزاری
end
