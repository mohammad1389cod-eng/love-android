function love.load()
    -- فعال کردن فیلتر ضد پیکسلی (Anti-aliasing) برای نرم شدن لبه‌ها
    love.graphics.setDefaultFilter("linear", "linear", 16)
    
    screenWidth = love.graphics.getWidth()
    screenHeight = love.graphics.getHeight()

    gameState = "playing"

    -- ۱. کاراکتر اصلی
    circleX = 100
    circleY = 300
    circleRadius = 20
    speed = 450
    targetX = 100
    targetY = 300

    -- ۲. سیستم امتیازدهی
    score = 0
    coinValue = 1 
    highScore = 0
    if love.filesystem.getInfo("highscore.txt") then
        local fileContent = love.filesystem.read("highscore.txt")
        highScore = tonumber(fileContent) or 0
    end

    -- ۳. سکه‌ها
    coins = {
        {x = math.random(50, screenWidth - 50), y = math.random(50, screenHeight - 50), radius = 12, active = true, timer = 0},
        {x = math.random(50, screenWidth - 50), y = math.random(50, screenHeight - 50), radius = 12, active = true, timer = 0},
        {x = math.random(50, screenWidth - 50), y = math.random(50, screenHeight - 50), radius = 12, active = true, timer = 0},
        {x = math.random(50, screenWidth - 50), y = math.random(50, screenHeight - 50), radius = 12, active = true, timer = 0}
    }

    -- ۴. بانک دشمنان
    allEnemies = {
        {x = math.random(100, screenWidth - 100), y = math.random(100, screenHeight - 100), radius = 25, speedX = 220, speedY = 220},
        {x = math.random(100, screenWidth - 100), y = math.random(100, screenHeight - 100), radius = 25, speedX = -270, speedY = 170},
        {x = math.random(100, screenWidth - 100), y = math.random(100, screenHeight - 100), radius = 25, speedX = 320, speedY = -220}
    }

    -- ۵. تنظیمات دکمه Replay
    buttonWidth = 200
    buttonHeight = 60
    buttonX = (screenWidth - buttonWidth) / 2
    buttonY = (screenHeight / 2) + 50
end

function love.update(dt)
    if gameState == "playing" then
        
        -- تنظیم سختی
        local activeEnemiesCount = 1 
        if score >= 100 and score < 200 then
            activeEnemiesCount = 2
            coinValue = 1
        elseif score >= 200 then
            activeEnemiesCount = 3
            coinValue = 2
        else
            coinValue = 1
        end

        -- بهینه‌سازی سیستم لمس برای افزایش فریم‌ریت
        local touches = love.touch.getTouches()
        if #touches > 0 then
            targetX, targetY = love.touch.getPosition(touches[1])
        end

        -- حرکت روان بازیکن بر اساس dt
        if circleX < targetX then circleX = math.min(targetX, circleX + speed * dt) end
        if circleX > targetX then circleX = math.max(targetX, circleX - speed * dt) end
        if circleY < targetY then circleY = math.min(targetY, circleY + speed * dt) end
        if circleY > targetY then circleY = math.max(targetY, circleY - speed * dt) end

        -- حرکت دشمنان
        for i = 1, activeEnemiesCount do
            local enemy = allEnemies[i]
            enemy.x = enemy.x + enemy.speedX * dt
            enemy.y = enemy.y + enemy.speedY * dt

            if enemy.x < enemy.radius then enemy.x = enemy.radius; enemy.speedX = -enemy.speedX
            elseif enemy.x > screenWidth - enemy.radius then enemy.x = screenWidth - enemy.radius; enemy.speedX = -enemy.speedX end

            if enemy.y < enemy.radius then enemy.y = enemy.radius; enemy.speedY = -enemy.speedY
            elseif enemy.y > screenHeight - enemy.radius then enemy.y = screenHeight - enemy.radius; enemy.speedY = -enemy.speedY end

            local distToEnemy = math.sqrt((circleX - enemy.x)^2 + (circleY - enemy.y)^2)
            if distToEnemy < (circleRadius + enemy.radius) then
                gameState = "gameover" 
            end
        end

        -- مدیریت سکه‌ها
        for i, coin in ipairs(coins) do
            if coin.active then
                local distance = math.sqrt((circleX - coin.x)^2 + (circleY - coin.y)^2)
                if distance < (circleRadius + coin.radius) then
                    score = score + coinValue 
                    coin.active = false
                    coin.timer = 0.5

                    if score > highScore then
                        highScore = score
                        love.filesystem.write("highscore.txt", tostring(highScore))
                    end
                end
            else
                coin.timer = coin.timer - dt
                if coin.timer <= 0 then
                    coin.x = math.random(50, screenWidth - 50)
                    coin.y = math.random(50, screenHeight - 50)
                    coin.active = true
                end
            end
        end

    elseif gameState == "gameover" then
        local touches = love.touch.getTouches()
        if #touches > 0 then
            local touchX, touchY = love.touch.getPosition(touches[1])
            if touchX > buttonX and touchX < buttonX + buttonWidth and
               touchY > buttonY and touchY < buttonY + buttonHeight then
                score = 0
                coinValue = 1
                circleX = 100
                circleY = 300
                targetX = 100
                targetY = 300
                for i = 1, 3 do
                    allEnemies[i].x = math.random(100, screenWidth - 100)
                    allEnemies[i].y = math.random(100, screenHeight - 100)
                end
                for _, coin in ipairs(coins) do
                    coin.x = math.random(50, screenWidth - 50)
                    coin.y = math.random(50, screenHeight - 50)
                    coin.active = true
                    coin.timer = 0
                end
                gameState = "playing"
            end
        end
    end
end

function love.draw()
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("SCORE: " .. score, 30, 40)
    love.graphics.print("HIGH SCORE: " .. highScore, 30, 80)
    
    if score >= 200 then
        love.graphics.setColor(0.2, 1, 0.2) 
        love.graphics.print("DOUBLE POINTS ACTIVE! (2x)", 30, 120)
    else
        love.graphics.setColor(1, 1, 1)
        love.graphics.print("LVL " .. (score >= 100 and "2" or "1") .. ": Get the coins!", 30, 120)
    end

    if gameState == "playing" then
        for i, coin in ipairs(coins) do
            if coin.active then
                love.graphics.setColor(1, 0.8, 0)
                love.graphics.circle("fill", coin.x, coin.y, coin.radius)
            end
        end

        local activeEnemiesCount = 1
        if score >= 100 and score < 200 then activeEnemiesCount = 2
        elseif score >= 200 then activeEnemiesCount = 3 end

        for i = 1, activeEnemiesCount do
            local enemy = allEnemies[i]
            love.graphics.setColor(1, 0.2, 0.2)
            love.graphics.circle("fill", enemy.x, enemy.y, enemy.radius)
        end

        love.graphics.setColor(1, 1, 1)
        love.graphics.circle("fill", circleX, circleY, circleRadius)

    elseif gameState == "gameover" then
        love.graphics.setColor(1, 0.2, 0.2)
        love.graphics.print("GAME OVER", screenWidth / 2 - 50, screenHeight / 2 - 50)
        
        love.graphics.setColor(0.2, 0.6, 1)
        love.graphics.rectangle("fill", buttonX, buttonY, buttonWidth, buttonHeight, 10, 10)
        
        love.graphics.setColor(1, 1, 1)
        love.graphics.print("REPLAY", buttonX + 70, buttonY + 20)
    end
end
